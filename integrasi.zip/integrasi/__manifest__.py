{
    'name': 'BC Purchase Invoice Integration',
    'version': '1.0',
    'depends': ['account'],
    'data': [
        'security/ir.model.access.csv',
        'views/vendor_bill_sync_views.xml',
    ],
    'installable': True,
    
    
}

#DAN-2025-ODOO-TO-BC-ICHITAN-PROJECT#
#INTEGRATION-TOKENAUTOMATIC#
#1-Mandays#
